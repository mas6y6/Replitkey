from setuptools import setup

long_description = """to use the replitkey tool click this link:https://github.com/mas6y6/Replitkey"""

setup(name='replitkey',
      version='2.4',
      description='ReplitKey can get database values from a repl project',
      author='mas6y6',
      packages=['replitkey'],
      long_description=long_description,
      zip_safe=False)